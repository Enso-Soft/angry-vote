package com.enso.angry_vote.ext

import com.enso.angry_vote.model.Vote
import com.enso.angry_vote.model.VoteSelect
import com.enso.angry_vote.model.VoteItem
import com.google.firebase.database.DataSnapshot

fun DataSnapshot.toVoteList(): List<VoteItem> {
    val list = mutableListOf<VoteItem>()
    for (voteSnapshot in this.children) {
        voteSnapshot.getValue(Vote::class.java)?.let {
            list.add(
                VoteItem(
                    uid = voteSnapshot.key ?: (it.id + it.timestamp),
                    id = it.id,
                    nickname = it.nickname,
                    reason = it.reason,
                    timestamp = it.timestamp
                )
            )
        }
    }
    return list
}

fun DataSnapshot.toVoteSelectList(): List<VoteSelect> {
    val list = mutableListOf<VoteSelect>()
    for (childrenSnapshot in this.children) {
        val id = childrenSnapshot.key ?: continue
        val nickname = childrenSnapshot.getValue(String::class.java) ?: continue
        list.add(
            VoteSelect(id = id, nickname = nickname)
        )
    }
    return list
}