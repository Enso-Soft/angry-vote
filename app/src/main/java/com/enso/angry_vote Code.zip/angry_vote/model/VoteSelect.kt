package com.enso.angry_vote.model

data class VoteSelect(
    val id: String,
    val nickname: String,
)