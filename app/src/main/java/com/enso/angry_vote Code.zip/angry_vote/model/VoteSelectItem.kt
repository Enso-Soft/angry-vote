package com.enso.angry_vote.model

data class VoteSelectItem(
    val id: String,
    val nickname: String,
    val voteCount: Int
)