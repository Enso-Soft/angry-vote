package com.enso.angry_vote

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.SimpleItemAnimator
import com.enso.angry_vote.adapter.vote_list.VoteListAdapter
import com.enso.angry_vote.adapter.vote_select.VoteSelectAdapter
import com.enso.angry_vote.base.BaseActivity
import com.enso.angry_vote.databinding.ActivityMainBinding
import com.enso.angry_vote.ext.toVoteList
import com.enso.angry_vote.ext.toVoteSelectList
import com.enso.angry_vote.model.Vote
import com.enso.angry_vote.model.VoteSelect
import com.enso.angry_vote.model.VoteSelectItem
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database
import java.util.Calendar

class MainActivity : BaseActivity<ActivityMainBinding>(ActivityMainBinding::inflate) {
    private val database: FirebaseDatabase by lazy { Firebase.database("https://angry-vote-default-rtdb.asia-southeast1.firebasedatabase.app/") }

    private val voteSelectAdapter by lazy { VoteSelectAdapter() }
    private val voteListAdapter by lazy { VoteListAdapter() }

    private var isBindVote: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupUi()
        subscribeVoteSelect()
        initListener()
    }

    private fun setupUi() {
        with(binding) {
            with(rvVoteSelect) {
                layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
                adapter = voteSelectAdapter
                (itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
            }

            with(rvVoteList) {
                layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.VERTICAL, false)
                adapter = voteListAdapter
            }
        }
    }

    private fun subscribeThisWeekVotes() {
        val startOfWeek = Calendar.getInstance().apply {
            // 현재 날짜를 기준으로 이번 주 월요일로 설정
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val endOfWeek = Calendar.getInstance().apply {
            // 이번 주 일요일로 설정
            add(Calendar.DAY_OF_WEEK, 6)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis

        // 쿼리 실행
        database.getReference("votes")
            .orderByChild("timestamp")
            .startAt(startOfWeek.toDouble())
            .endAt(endOfWeek.toDouble())
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val weeklyVotes = snapshot.toVoteList()

                    voteListAdapter.submitList(
                        weeklyVotes.sortedByDescending { it.timestamp }
                    ) {
                        binding.rvVoteList.scrollToPosition(0)
                    }

                    setVoteSelectItemList(
                        voteSelectAdapter.currentList.map { voteSelect ->
                            voteSelect.copy(
                                voteCount = weeklyVotes.count { it.id == voteSelect.id }
                            )
                        }
                    )
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun subscribeVoteSelect() {
        database.getReference("vote_select")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val voteSelectList = snapshot.toVoteSelectList()
                    val holderVoteSelectItemList = voteSelectAdapter.currentList

                    setVoteSelectItemList(
                        voteSelectList.map { voteSelect ->
                            VoteSelectItem(
                                id = voteSelect.id,
                                nickname = voteSelect.nickname,
                                voteCount = (holderVoteSelectItemList.find { it.id == voteSelect.id }?.voteCount ?: 0))
                        }
                    )

                    if (!isBindVote) {
                        isBindVote = true
                        subscribeThisWeekVotes()
                    }
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun initListener() {
        voteSelectAdapter.setOnVoteSelectListener(object : VoteSelectAdapter.OnVoteSelectListener {
            override fun onClick(item: VoteSelectItem) {
                val reasonText = binding.etReason.text.toString()
                if (reasonText.isBlank()) {
                    Toast.makeText(this@MainActivity, "사유를 적어주십쇼", Toast.LENGTH_SHORT).show()
                    return
                }

                database.getReference("votes")
                    .push()
                    .setValue(
                        Vote(
                            id = item.id,
                            nickname = item.nickname,
                            reason = reasonText,
                        )
                    )
                    .addOnSuccessListener {
                        Toast.makeText(this@MainActivity, "${item.nickname}님 한표 드림!", Toast.LENGTH_SHORT).show()
                        binding.etReason.text.clear()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this@MainActivity, "투표 실패 했는걸?", Toast.LENGTH_SHORT).show()
                    }
            }
        })
    }

    private fun setVoteSelectItemList(list: List<VoteSelectItem>) {
        voteSelectAdapter.submitList(list)
    }
}